<?php
// +-----------------------------------------------------------------------+
// | Piwigo - a PHP based photo gallery                                    |
// +-----------------------------------------------------------------------+
// | Copyright(C) 2008-2014 Piwigo Team                  http://piwigo.org |
// | Copyright(C) 2003-2008 PhpWebGallery Team    http://phpwebgallery.net |
// | Copyright(C) 2002-2003 Pierrick LE GALL   http://le-gall.net/pierrick |
// +-----------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or modify  |
// | it under the terms of the GNU General Public License as published by  |
// | the Free Software Foundation                                          |
// |                                                                       |
// | This program is distributed in the hope that it will be useful, but   |
// | WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |
// | General Public License for more details.                              |
// |                                                                       |
// | You should have received a copy of the GNU General Public License     |
// | along with this program; if not, write to the Free Software           |
// | Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, |
// | USA.                                                                  |
// +-----------------------------------------------------------------------+
$lang['locfiledit_file_already_exists'] = 'கோப்பு ஏற்கனவே உள்ளது.';
$lang['locfiledit_edit'] = 'திருத்துக';
$lang['locfiledit_empty_filename'] = 'நீங்கள் கோப்பின் பெயரை உள்ளிட வேண்டும்.';
$lang['locfiledit_empty_page'] = 'வெற்று பக்கம்';
$lang['locfiledit_choose_file'] = 'திருத்த வேண்டும் என்ற கோப்பினை தேர்வுசெய்க
';
$lang['locfiledit_bak_loaded1'] = 'மறுபிரதி கோப்பு ஏற்றப்படும்.';
$lang['locfiledit_bak_loaded2'] = 'அதை மீட்க கோப்பு சேமிக்க வேண்டும்.';
$lang['locfiledit_cant_save'] = 'தற்போதைய கோப்பு எழுதக்கூடிய அல்ல. கோப்பகம் "local/" எழுதக்கூடிய (chmod) என்று சரிபார்க்கவும்.';
$lang['locfiledit_onglet_lang'] = 'மொழிகள்';
$lang['locfiledit_onglet_localconf'] = 'உள் கட்டமைப்பு';
$lang['locfiledit_onglet_plug'] = 'தனிப்பட்ட செருகுநிரல்';
$lang['locfiledit_onglet_tpl'] = 'வார்ப்புருக்கள்';
$lang['locfiledit_filename_error'] = 'கோப்பு பெயர் எழுத்துக்கள் தடை.';
$lang['locfiledit_model'] = 'மாதிரி';
$lang['locfiledit_model_error'] = 'நீங்கள் ஒரு மாதிரி தேர்வு செய்ய வேண்டும்.';
$lang['locfiledit_new_filename'] = 'கோப்பு பெயர்';
$lang['locfiledit_new_tpl'] = 'புதிய கோப்பு உருவாக்க';
?>